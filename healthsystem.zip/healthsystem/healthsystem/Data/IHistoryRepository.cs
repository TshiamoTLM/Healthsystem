﻿using healthsystem.Models;
namespace healthsystem.Data
{
    public interface IHistoryRepository: IRepositoryBase<History>
    {
    }
}