﻿using healthsystem.Models;

namespace healthsystem.Data
{
    public interface IConsultationRepository: IRepositoryBase<Consultation>
    {
    }
}