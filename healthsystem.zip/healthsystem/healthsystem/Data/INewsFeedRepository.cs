﻿using healthsystem.Models;

namespace healthsystem.Data
{
    public interface INewsFeedRepository : IRepositoryBase<NewsFeed>
    {
    }
}
