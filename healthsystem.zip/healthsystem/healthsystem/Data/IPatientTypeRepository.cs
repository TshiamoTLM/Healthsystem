﻿using healthsystem.Models;

namespace healthsystem.Data
{
    public interface IPatientTypeRepository: IRepositoryBase<PatientType>
    {
    }
}