﻿using healthsystem.Models;

namespace healthsystem.Data
{
    public interface IWorkerTypeRepository:IRepositoryBase<WorkerType>
    {
    }
}